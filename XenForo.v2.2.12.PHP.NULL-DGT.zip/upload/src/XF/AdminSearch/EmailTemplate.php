<?php

namespace XF\AdminSearch;

class EmailTemplate extends PublicTemplate
{
	protected function getSearchTemplateType()
	{
		return 'email';
	}
}